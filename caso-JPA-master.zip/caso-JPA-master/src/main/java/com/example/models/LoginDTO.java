/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.models;

import javax.persistence.Entity;

/**
 *
 * @author user
 */
public class LoginDTO {
    
    private String email;
    private String contrasena;

    public LoginDTO() {
    }
   

  
    public String getEmail() {
        return email;
    }

  
    public void setEmail(String email) {
        this.email = email;
    }

   
    public String getContrasena() {
        return contrasena;
    }

   
    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }
    
    
}
